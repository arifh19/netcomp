<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title Page-->
    <title>Net Competition 2019</title>

    <!-- Fontfaces CSS-->
    <link href="<?php echo e(asset('/css/font-face.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('/vendor/font-awesome-4.7/css/font-awesome.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('/vendor/font-awesome-5/css/fontawesome-all.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('/vendor/mdi-font/css/material-design-iconic-font.min.css')); ?>" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="<?php echo e(asset('/vendor/bootstrap-4.1/bootstrap.min.css')); ?>" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="<?php echo e(asset('/vendor/animsition/animsition.min.css')); ?>" rel="stylesheet" media="all">
    
    <link href="<?php echo e(asset('/vendor/wow/animate.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('/vendor/css-hamburgers/hamburgers.min.css')); ?>" rel="stylesheet" media="all">
    
    

    <!-- Main CSS-->
    <link href="<?php echo e(asset('/css/theme.css')); ?>" rel="stylesheet" media="all">


</head>

<body class="animsition" style="background-color:#e5e5e5">
    <div class="page-wrapper">


        <!-- PAGE CONTAINER-->
            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="container">
                <div class="login-wrap">
                    <div class="login-content">
                        <div class="login-logo">

                                <img src="<?php echo e(asset('/img/netcomp.png')); ?>" alt="CoolAdmin">

                        </div>
                        <div class="login-form">
                        <form action="<?php echo e(route('login')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label>Email Address</label>
                                    <input class="au-input au-input--full" type="email" name="email" placeholder="Email" required>
                                </div>
                                <div class="form-group">
                                    <label>Password</label>
                                    <input class="au-input au-input--full" type="password" name="password" placeholder="Password" required>
                                </div>
                                <div class="login-checkbox">
                                    <label>
                                        <input type="checkbox" name="remember">Remember Me
                                    </label>
                                    
                                </div>
                                <button class="au-btn au-btn--block au-btn--green m-b-20" type="submit">sign in</button>
                            </form>
                            <div class="register-link">
                                <p>
                                    Don't you have account?
                                    <a href="<?php echo e(route('register')); ?>">Sign Up Here</a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>

            <footer>
                <div class="row">
                    <div class="col-md-12">
                        <div class="copyright">
                           <p>Copyright © 2019 Teknologi Rekayasa Internet. All rights reserved. visit <a href="https://tri.sv.ugm.ac.id">Net Competition 2019</a>.</p>
                        </div>
                    </div>
                </div>
            </footer>
    </div>
    <?php echo $__env->yieldContent('scripts'); ?>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Jquery JS-->
    <script src="<?php echo e(asset('/vendor/jquery-3.2.1.min.js')); ?>"></script>
    <!-- Bootstrap JS-->
    
    <script src="<?php echo e(asset('/vendor/bootstrap-4.1/bootstrap.min.js')); ?>"></script>
    <!-- Vendor JS       -->
    
    
    <script src="<?php echo e(asset('/vendor/animsition/animsition.min.js')); ?>"></script>
    
    
    <script src="<?php echo e(asset('/css/font-face.css')); ?>"></script>
    

    <!-- Main JS-->
    <script src="<?php echo e(asset('/js/main.js')); ?>"></script>

</body>

</html>
<!-- end document-->
