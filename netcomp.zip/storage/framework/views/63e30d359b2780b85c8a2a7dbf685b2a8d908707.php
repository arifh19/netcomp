<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title Page-->
    <title>Net Competition 2019</title>

    <!-- Fontfaces CSS-->
    <link href="<?php echo e(asset('/css/font-face.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('/vendor/font-awesome-4.7/css/font-awesome.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('/vendor/font-awesome-5/css/fontawesome-all.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('/vendor/mdi-font/css/material-design-iconic-font.min.css')); ?>" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="<?php echo e(asset('/vendor/bootstrap-4.1/bootstrap.min.css')); ?>" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="<?php echo e(asset('/vendor/animsition/animsition.min.css')); ?>" rel="stylesheet" media="all">
    
    <link href="<?php echo e(asset('/vendor/wow/animate.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('/vendor/css-hamburgers/hamburgers.min.css')); ?>" rel="stylesheet" media="all">
    
    

    <!-- Main CSS-->
    <link href="<?php echo e(asset('/css/theme.css')); ?>" rel="stylesheet" media="all">


</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <header class="header-mobile d-block d-lg-none">
            <div class="header-mobile__bar">
                <div class="container-fluid">

                    <div class="header-mobile-inner">

                        <button class="hamburger hamburger--slider" type="button">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <nav class="navbar-mobile">
                <div class="container-fluid">
                    <ul class="navbar-mobile__list list-unstyled">
                                <?php if(auth()->user()->hasRole('admin')): ?>
                                    <li>
                                    <a href="/">
                                        <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                                    </li>
                                <?php elseif(auth()->user()->hasRole('peserta')): ?>
                                    <?php if(\App\Team::where('user_id', auth()->user()->id)->count()<1): ?>
                                        <li>
                                        <a href="<?php echo e(route('home')); ?>">
                                                <i class="fas fa-tachometer-alt"></i>Data Tim</a>
                                        </li>
                                    <?php else: ?>
                                        <li>
                                        <a href="<?php echo e(route('home')); ?>">
                                            <i class="fas fa-tachometer-alt"></i>Pengumuman</a>
                                        </li>
                                        <li>
                                        <a href="<?php echo e(route('peserta.tim')); ?>">
                                            <i class="fas fa-users"></i>Team</a>
                                        </li>
                                        <?php if(\App\Team::where('user_id', auth()->user()->id)->first()->kategori_id==1): ?>
                                            <li>
                                            <a href="<?php echo e(route('peserta.proposal')); ?>">
                                                <i class="fas fa-book"></i>&nbspUpload Proposal</a>
                                            </li>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php else: ?>
                                <?php endif; ?>
                    </ul>
                </div>
            </nav>
        </header>
        <!-- END HEADER MOBILE-->

        <!-- MENU SIDEBAR-->
        <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="/">
                    <img src="<?php echo e(asset('/img/netcomp.png')); ?>" alt="Net Competition" />
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <?php if(auth()->user()->hasRole('admin')): ?>
                        <li>
                            <a href="/">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                            </li>
                        <?php elseif(auth()->user()->hasRole('peserta')): ?>
                            <?php if(\App\Team::where('user_id', auth()->user()->id)->count()<1): ?>
                                <li>
                                <a href="<?php echo e(route('home')); ?>">
                                        <i class="fas fa-tachometer-alt"></i>Data Tim</a>
                                </li>
                            <?php else: ?>
                                <li>
                                <a href="<?php echo e(route('home')); ?>">
                                    <i class="fas fa-tachometer-alt"></i>Pengumuman</a>
                                </li>
                                <li>
                                <a href="<?php echo e(route('peserta.tim')); ?>">
                                    <i class="fas fa-users"></i>Team</a>
                                </li>
                                <?php if(\App\Team::where('user_id', auth()->user()->id)->first()->kategori_id==1): ?>
                                    <li>
                                        <a href="<?php echo e(route('peserta.proposal')); ?>">
                                        <i class="fas fa-book"></i>&nbspUpload Proposal</a>
                                    </li>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php else: ?>
                        <?php endif; ?>

                    </ul>
                </nav>
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <header class="header-desktop">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                            <form class="form-header" action="" method="POST">

                            </form>
                            <div class="header-button">
                                <div class="noti-wrap">
                                    <div class="noti__item js-item-menu">
                                        </div>
                                        </div>

                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                            <img src="<?php echo e(asset('/img/'. auth()->user()->avatar)); ?>" alt="<?php echo e(auth()->user()->name); ?>" />
                                        </div>
                                        <div class="content">
                                            <a class="js-acc-btn" href="#"><?php echo e(auth()->user()->name); ?></a>
                                        </div>
                                        <div class="account-dropdown js-dropdown">
                                            <div class="info clearfix">
                                                <div class="image">
                                                    <a href="#">
                                                        <img src="<?php echo e(asset('/img/'. auth()->user()->avatar)); ?>" alt="<?php echo e(auth()->user()->name); ?>" />
                                                    </a>
                                                </div>
                                                <div class="content">
                                                    <h5 class="name">
                                                        <a href="#"><?php echo e(auth()->user()->name); ?></a>
                                                    </h5>
                                                    <span class="email"><?php echo e(auth()->user()->email); ?></span>
                                                </div>
                                            </div>
                                            <div class="account-dropdown__body">
                                                <div class="account-dropdown__item">
                                                    <a href="#">
                                                        <i class="zmdi zmdi-account"></i>Account</a>
                                                </div>
                                                <div class="account-dropdown__item">
                                                    <a href="#">
                                                        <i class="zmdi zmdi-settings"></i>Setting</a>
                                                </div>
                                            </div>
                                            <div class="account-dropdown__footer">
                                            <a href="<?php echo e(route('logout')); ?>">
                                                    <i class="zmdi zmdi-power"></i>Logout</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>
            </div>
            <footer>
                <div class="row">
                    <div class="col-md-12">
                        <div class="copyright">
                           <p>Copyright © 2019 Teknologi Rekayasa Internet. All rights reserved. visit <a href="https://netcomp.web.id">Net Competition 2019</a>.</p>
                        </div>
                    </div>
                </div>
            </footer>
            <!-- END MAIN CONTENT-->
            <!-- END PAGE CONTAINER-->
        </div>

    </div>
    <?php echo $__env->yieldContent('scripts'); ?>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Jquery JS-->
    <script src="<?php echo e(asset('/vendor/jquery-3.2.1.min.js')); ?>"></script>
    <!-- Bootstrap JS-->
    
    <script src="<?php echo e(asset('/vendor/bootstrap-4.1/bootstrap.min.js')); ?>"></script>
    <!-- Vendor JS       -->
    
    
    <script src="<?php echo e(asset('/vendor/animsition/animsition.min.js')); ?>"></script>
    
    
    <script src="<?php echo e(asset('/css/font-face.css')); ?>"></script>
    

    <!-- Main JS-->
    <script src="<?php echo e(asset('/js/main.js')); ?>"></script>

</body>

</html>
<!-- end document-->
