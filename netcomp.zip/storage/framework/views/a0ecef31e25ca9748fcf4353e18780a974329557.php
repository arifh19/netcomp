<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title Page-->
    <title>Net Competition 2019</title>

    <!-- Fontfaces CSS-->
    <link href="<?php echo e(asset('/css/font-face.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('/vendor/font-awesome-4.7/css/font-awesome.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('/vendor/font-awesome-5/css/fontawesome-all.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('/vendor/mdi-font/css/material-design-iconic-font.min.css')); ?>" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="<?php echo e(asset('/vendor/bootstrap-4.1/bootstrap.min.css')); ?>" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="<?php echo e(asset('/vendor/animsition/animsition.min.css')); ?>" rel="stylesheet" media="all">
    
    <link href="<?php echo e(asset('/vendor/wow/animate.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('/vendor/css-hamburgers/hamburgers.min.css')); ?>" rel="stylesheet" media="all">
    
    

    <!-- Main CSS-->
    <link href="<?php echo e(asset('/css/theme.css')); ?>" rel="stylesheet" media="all">


</head>

<body class="animsition" style="background-color:#e5e5e5">
    <div class="page-wrapper">


        <!-- PAGE CONTAINER-->
            <!-- MAIN CONTENT-->
            <div class="main-content">
                    <div class="container">
                            <div class="login-wrap">
                                <div class="login-content">
                                    <div class="login-logo">

                                            <img src="<?php echo e(asset('/img/netcomp.png')); ?>" alt="CoolAdmin">

                                    </div>
                                    <div class="login-form">
                                            <form enctype="multipart/form-data" method="POST" action="<?php echo e(route('register')); ?>">
                                                <?php echo csrf_field(); ?>

                                                <div class="form-group row">
                                                    <label for="name" class="col-sm-4 col-form-label"><?php echo e(__('Name')); ?></label>

                                                    <div class="col-sm-7">
                                                        <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus placeholder="Name ">

                                                        <?php if($errors->has('name')): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('name')); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <label for="email" class="col-sm-4 col-form-label"><?php echo e(__('E-Mail Address')); ?></label>

                                                    <div class="col-sm-7">
                                                        <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required placeholder="Email">

                                                        <?php if($errors->has('email')): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('email')); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <label for="password" class="col-sm-4 col-form-label"><?php echo e(__('Password')); ?></label>

                                                    <div class="col-sm-7">
                                                        <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required placeholder="Password">

                                                        <?php if($errors->has('password')): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('password')); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <label for="password-confirm" class="col-sm-4 col-form-label"><?php echo e(__('Confirm Password')); ?></label>

                                                    <div class="col-sm-7">
                                                        <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required placeholder="Confirm Password">
                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <label for="avatar" class="col-sm-4 col-form-label"><?php echo e(__('Foto Profil')); ?></label>

                                                    <div class="col-sm-7">
                                                        <input id="avatar" type="file" class="form-control" name="avatar" required>
                                                    </div>
                                                </div>

                                                <div class="form-group row mb-0">
                                                    <div class="col-sm-7 offset-sm-4">
                                                        <button type="submit" class="au-btn au-btn--block au-btn--green m-b-20">
                                                            <?php echo e(__('Register')); ?>

                                                        </button>
                                                    </div>
                                                </div>
                                            </form>
                                        <div class="register-link">
                                            <p>
                                                    Already have account?
                                                <a href="<?php echo e(route('login')); ?>">Sign in Here</a>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
            </div>

            <footer>
                <div class="row">
                    <div class="col-md-12">
                        <div class="copyright">
                           <p>Copyright © 2019 Teknologi Rekayasa Internet. All rights reserved. visit <a href="https://tri.sv.ugm.ac.id">Net Competition 2019</a>.</p>
                        </div>
                    </div>
                </div>
            </footer>
    </div>
    <?php echo $__env->yieldContent('scripts'); ?>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Jquery JS-->
    <script src="<?php echo e(asset('/vendor/jquery-3.2.1.min.js')); ?>"></script>
    <!-- Bootstrap JS-->
    
    <script src="<?php echo e(asset('/vendor/bootstrap-4.1/bootstrap.min.js')); ?>"></script>
    <!-- Vendor JS       -->
    
    
    <script src="<?php echo e(asset('/vendor/animsition/animsition.min.js')); ?>"></script>
    
    
    <script src="<?php echo e(asset('/css/font-face.css')); ?>"></script>
    

    <!-- Main JS-->
    <script src="<?php echo e(asset('/js/main.js')); ?>"></script>

</body>

</html>
<!-- end document-->
