<?php $__env->startSection('content'); ?>

<?php if(auth()->user()->hasRole('admin')): ?>
You are Admin
<?php elseif(auth()->user()->hasRole('reviewer')): ?>
You are Reviewer
<?php elseif(auth()->user()->hasRole('peserta')): ?>
    <div class="row">
        <div class="col-lg-2 center">
        </div>
        <div class="col-lg-8 center">
            <div class="card">
                <div class="card-header"><center>Net Competition</center></div>
                <div class="card-body">
                    <div class="card-title">
                        <h3 class="text-center title-2">Papan Pengumuman</h3>
                    </div>
                    <hr>

                    <br>
                    <center>Belum ada informasi</center>

                </div>
            </div>
        </div>
    </div>
<?php else: ?>

<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>